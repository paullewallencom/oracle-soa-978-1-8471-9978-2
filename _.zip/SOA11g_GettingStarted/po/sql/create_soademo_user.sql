grant connect, resource to soademo identified by soademo;
Exit;

